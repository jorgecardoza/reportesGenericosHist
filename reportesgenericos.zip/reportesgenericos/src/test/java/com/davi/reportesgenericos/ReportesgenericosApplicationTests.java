package com.davi.reportesgenericos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportesgenericosApplicationTests {

	@Test
	void contextLoads() {
	}

}
