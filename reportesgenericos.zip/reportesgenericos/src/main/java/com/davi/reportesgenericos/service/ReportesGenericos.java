//package com.davi.reportesgenericos.service;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@FeignClient(name = "moto-service",url = "http://localhost:8003")
//@RequestMapping("/moto")
//public interface ReportesGenericos {
//
//}
