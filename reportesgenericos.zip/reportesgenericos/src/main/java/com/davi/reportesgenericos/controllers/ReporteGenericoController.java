package com.davi.reportesgenericos.controllers;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

//
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController@RequestMapping(value="/getpdf", method=RequestMethod.POST)
public class ReporteGenericoController{
public void getPDF(@RequestBody String json) {
	try {
	String enpoid="";
	 // URL del endpoint
    String endpointUrl = "https://api.example.com/data";

    // Crear una URL desde la dirección del endpoint
    URL url = new URL(endpointUrl);

    // Abrir una conexión HTTP
HttpURLConnection conn = (HttpURLConnection) url.openConnection();

    // Establecer el método de la solicitud (GET, POST, PUT, DELETE, etc.)
    conn.setRequestMethod("GET");

    // Leer la respuesta del servidor
    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
    StringBuilder response = new StringBuilder();
    String line;
while ((line = reader.readLine()) != null) {
        response.append(line);
    }
    reader.close();

    // Procesar la respuesta
    System.out.println("Respuesta del servidor:");
    System.out.println(response.toString());

    // Cerrar la conexión
    conn.disconnect();
} catch (Exception e) {
    e.printStackTrace();
}

    // convert JSON to Employee 
//    Employee emp = convertSomehow(json);
//
//    // generate the file
//    PdfUtil.showHelp(emp);
//
//    // retrieve contents of "C:/tmp/report.pdf" that were written in showHelp
//    byte[] contents = (...);  //aqui es lo importante, se lee en archivo en todo caso tocaria el BASE64 a archivo y luego a Bytes
//
//    HttpHeaders headers = new HttpHeaders();
//    headers.setContentType(MediaType.APPLICATION_PDF);
//    // Here you have to set the actual filename of your pdf
//    String filename = "output.pdf";
//    headers.setContentDispositionFormData(filename, filename);
//    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
//    ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
//    return response;

}
}

