package com.davi.reportesgenericos.controllers;

import java.util.Map;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.davi.reportesgenericos.service.ConsumeApiService;
import com.davi.reportesgenericos.utils.DocxHandling;
//import com.github.cliftonlabs.json_simple.JsonObject;
//import com.github.cliftonlabs.json_simple.Jsoner;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@RestController
//@RequestMapping(value = "/getpdf", method = RequestMethod.POST)
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST })
public class ReporteGenericoController {

	@Autowired
	private ConsumeApiService consumeApiService;
	@Autowired
	private DocxHandling docxHService;

	private Map<String, String> textsToReplace;
	private String originalFilePath;

	private String temporalFileName;

	private XWPFDocument doc;

	@RequestMapping(value = "/getpdf", method = RequestMethod.GET)

	public void getPDF(@RequestBody String jsonRecibido) {
		
		String jsonInput = "{" + "\"reporte\":\"EJCREDIPMIGC\"," + "\"sistema\":\"2\"," + "\"producto\":\"1\","
				+ "\"datosReporte\":{" + "\"fechaMes\":\"Enero\"," + "\"fechaAnio\":\"2023\"," + "\"fechaDia\":\"13\","
				+ "\"montoAprobado\":10000.00," + "\"nombreCliente\":\"Daniel Ernesto Méndez Lazo\"" + "}" + "}";

		System.out.println("IMPRIMIEDO el JSON entrada" + jsonInput);
		

//Extraer el valor de los campos deljsonImput
		Gson gson = new Gson();
		JsonObject jsonImpu = gson.fromJson(jsonInput, JsonObject.class);

		String reporte = jsonImpu.get("reporte").getAsString();
		String sistema = jsonImpu.get("sistema").getAsString();
		String producto = jsonImpu.get("producto").getAsString();
		System.out.println("Reporte: " + reporte);
		System.out.println("Sistema: " + sistema);
		System.out.println("Producto: " + producto);

		String jsonRespuesta = consumeApiService.getReporte(reporte,sistema,producto);
		
		JsonObject jsonRecibid = gson.fromJson(jsonRespuesta, JsonObject.class);
		System.out.println("Respuesta Api Raul" + jsonRespuesta);
		// Convierte la cadena de texto JSON a un objeto JSON
     //  JsonObject jsonObject = Jsoner.deserialize(jsonRespuesta, new JsonObject());
		//jsonImpu es el que se recibe de resposebody
		//es json de respuesta de la api de raul
		
		
		System.out.println("json ------ ANTES de anviar al main"+jsonRecibid);
		docxHService.main(jsonImpu, jsonRecibid);
		
		
		
	}
}
