package com.davi.reportesgenericos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportesgenericosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportesgenericosApplication.class, args);
	}

}
